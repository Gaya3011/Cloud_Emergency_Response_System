const form = document.getElementById("emergencyForm");
const message = document.getElementById("message");
const incidentList = document.getElementById("incidentList");
const searchInput = document.getElementById("searchInput");
const statusFilter = document.getElementById("statusFilter");
const refreshButton = document.getElementById("refreshButton");
const descriptionInput = document.getElementById("description");
let incidentsCache = [];

document.getElementById("todayLabel").textContent =
  new Intl.DateTimeFormat("en-IN", { dateStyle: "medium" }).format(new Date());

descriptionInput.addEventListener("input", () => {
  document.getElementById("charCount").textContent =
    `${descriptionInput.value.length} / 1000`;
});

function setMessage(text, isError = false) {
  message.textContent = text;
  message.classList.toggle("error", isError);
}

function makeElement(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}

function statusClass(status) {
  if (status === "Resolved") return "resolved";
  if (status === "In Progress") return "in-progress";
  return "";
}

function renderIncidents() {
  const search = searchInput.value.trim().toLowerCase();
  const filter = statusFilter.value;
  const visible = incidentsCache.filter(item => {
    const matchesSearch = [item.type, item.location, item.name, item.description]
      .some(value => String(value || "").toLowerCase().includes(search));
    return matchesSearch && (filter === "All" || item.status === filter);
  });

  document.getElementById("total").textContent = incidentsCache.length;
  document.getElementById("pending").textContent =
    incidentsCache.filter(item => item.status === "Pending").length;
  document.getElementById("inProgress").textContent =
    incidentsCache.filter(item => item.status === "In Progress").length;
  document.getElementById("resolved").textContent =
    incidentsCache.filter(item => item.status === "Resolved").length;

  incidentList.replaceChildren();

  if (visible.length === 0) {
    const empty = makeElement("div", "empty-state");
    empty.append(
      makeElement("span", "empty-icon", "▤"),
      makeElement("strong", "", incidentsCache.length ? "No matching reports" : "No reports yet"),
      makeElement("p", "", incidentsCache.length
        ? "Try changing your search or status filter."
        : "Submitted incident reports will appear here.")
    );
    incidentList.appendChild(empty);
    return;
  }

  visible.forEach(item => {
    const card = makeElement("article", "incident");
    const top = makeElement("div", "incident-top");
    const headingGroup = document.createElement("div");
    headingGroup.append(
      makeElement("h3", "", `${item.type} Emergency`),
      makeElement("div", "incident-meta", `ID: ${item.id.slice(-10)}`)
    );
    top.append(
      headingGroup,
      makeElement("span", `status-badge ${statusClass(item.status)}`, item.status)
    );

    const location = makeElement("p", "incident-meta", `⌖ ${item.location} · Reported by ${item.name}`);
    const description = makeElement("p", "incident-description", item.description);
    const created = makeElement("p", "incident-meta",
      `Submitted: ${new Date(item.createdAt).toLocaleString()}`);

    const actions = makeElement("div", "incident-actions");
    const select = document.createElement("select");
    select.setAttribute("aria-label", `Status for ${item.type} incident`);
    ["Pending", "In Progress", "Resolved"].forEach(value => {
      const option = document.createElement("option");
      option.value = value;
      option.textContent = value;
      select.appendChild(option);
    });
    select.value = item.status;

    const button = makeElement("button", "", "Save status");
    button.type = "button";
    button.addEventListener("click", async () => {
      button.disabled = true;
      button.textContent = "Saving...";
      try {
        const response = await fetch(`/api/incidents/${encodeURIComponent(item.id)}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ status: select.value })
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.message || "Could not update status.");
        setMessage(result.message);
        await loadIncidents();
      } catch (error) {
        setMessage(error.message, true);
      } finally {
        button.disabled = false;
        button.textContent = "Save status";
      }
    });

    actions.append(select, button);
    card.append(top, location, description, created, actions);
    incidentList.appendChild(card);
  });
}

async function loadIncidents() {
  refreshButton.disabled = true;
  try {
    const response = await fetch("/api/incidents");
    if (!response.ok) throw new Error("Could not load incident reports.");
    incidentsCache = await response.json();
    renderIncidents();
  } catch (error) {
    incidentList.replaceChildren(
      makeElement("div", "empty-state", "Could not connect to the backend. Start the server and refresh.")
    );
  } finally {
    refreshButton.disabled = false;
  }
}

form.addEventListener("submit", async event => {
  event.preventDefault();
  const submitButton = form.querySelector('button[type="submit"]');
  submitButton.disabled = true;
  setMessage("Submitting report...");

  const report = {
    name: form.elements.name.value.trim(),
    type: form.elements.type.value,
    location: form.elements.location.value.trim(),
    description: form.elements.description.value.trim()
  };

  try {
    const response = await fetch("/api/incidents", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(report)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.message || "Submission failed.");
    form.reset();
    document.getElementById("charCount").textContent = "0 / 1000";
    setMessage(result.message);
    await loadIncidents();
    document.getElementById("incidents").scrollIntoView({ behavior: "smooth" });
  } catch (error) {
    setMessage(`${error.message} Check that the server is running.`, true);
  } finally {
    submitButton.disabled = false;
  }
});

searchInput.addEventListener("input", renderIncidents);
statusFilter.addEventListener("change", renderIncidents);
refreshButton.addEventListener("click", loadIncidents);
loadIncidents();